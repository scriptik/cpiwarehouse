rem_sec = str(120-3)
print(len(rem_sec))
dig_pos = {"0":5,"1":35,"2":65,"3":95,"4":125,"5":155,"6":185,"7":215,"8":245,"9":275}
x2 = dig_pos[rem_sec[1]]
print(type(x2))

