#!/usr/bin/python3
#MASTERMIND FOR GAMESHELL CLOCKWORK
#https://github.com/scriptik/cpiwarehouse
#Pezhman Shafigh
#October 2020

import pygame
import os
import random
import pickle
#import logging
from pygame.locals import *

# Call this function so the Pygame library can initialize itself
pygame.init()
display_width = pygame.display.Info().current_w
display_height = pygame.display.Info().current_h
#print(display_width, display_height)
if display_width == 320 and display_height == 240:
   screen = pygame.display.set_mode([320, 240], pygame.FULLSCREEN)
else :
   screen = pygame.display.set_mode([320, 240])

# This sets the name of the window
pygame.display.set_caption('Mastermind')

# Before the loop, load the sounds:
#checkPoint_sound = pygame.mixer.Sound('checkPoint.wav')

background = pygame.Surface(screen.get_size())
background.fill((255,255,255))     # fill the background white
background = background.convert()  # prepare for faster blitting
screen.blit(background, (0,0))

clock = pygame.time.Clock()
FPS = 30 # desired framerate in frames per second. try out other values !

class blctrl():
    def __init__(self):
        self.bl = 1
    def writebl(self, new):
        self.bl = new
        with open('level.dat', 'wb') as file:
            pickle.dump(new, file)

    def readbl(self):
        try:
            with open('level.dat', 'rb') as file:
                self.bl = pickle.load(file)
        except:
            self.bl = 11

blctrl = blctrl()
blctrl.readbl()

class mmgame():
    run = False
    runlevel = 0
    maxlevel = 0
    colorAttemp = (
                  (4,4,10), (4,4,7), (4,5,10), (4,5,7), (4,6,10),
                  (4,6,7), (5,5,10), (5,5,7), (5,6,10), (5,6,7),
                  (6,6,10), (6,6,7)
                  )
    colorcircle_list = []
    allcolor = (0,1,2,3,4,5,6)
    wbcircle_list = []
    endicons_list = []
    blankcirclexy = ((20,219),(45,219),(70,219),(95,219),(120,219),(145,219))
    def __init__(self):
        self.runlevel = mmgame.runlevel
        self.hlineicon = allsign.subsurface((15,175,245,1))
        #self.vlineicon = allsign.subsurface((305,5,1,230))
        self.covericon = main_menu.backimage_list[0].subsurface((25,195,20,20))
        self.nucolor = mmgame.colorAttemp[mmgame.runlevel-1][0]
        self.unknowcolor = mmgame.colorAttemp[mmgame.runlevel-1][1]
        self.maxattemp = mmgame.colorAttemp[mmgame.runlevel-1][2]
        self.activerow = 0
        self.activecolumn = 0
        self.askrepeat = False
        self.avcolor = mmgame.allcolor[1:self.unknowcolor+1]
        self.avlistpointer = 0
        self.zerorow = [0,0,0,0,0,0]
        self.allanswers = []
        self.allresponse = []
        self.allfoundcolors = []
        self.unnexlevel = False

    def ranans(self):
        self.finalanswer = []
        self.finalanswer = random.sample(self.avcolor, self.nucolor)
        print(self.finalanswer)

    def levelcoat(self):
        self.activerow = 0
        self.nucolor = mmgame.colorAttemp[mmgame.runlevel-1][0]
        self.unknowcolor = mmgame.colorAttemp[mmgame.runlevel-1][1]
        self.maxattemp = mmgame.colorAttemp[mmgame.runlevel-1][2]
        self.avcolor = list(mmgame.allcolor[1:self.unknowcolor+1])
        self.selectedcolor = mmgame.zerorow[:self.nucolor]
        print(self.selectedcolor)
        print(mmgame.runlevel, mmgame.nucolor, mmgame.unknowcolor, mmgame.maxattemp, mmgame.avcolor)
        self.ranans()
        self.rowResponse = []
        self.allanswers = []
        self.allresponse = []
        self.activerow = 0
        self.activecolumn = 0
        self.allfoundcolors = []

    def afterwin(self):
        self.unnexlevel = True
        self.askrepeat = True
        self.winlosticon = 0

    def afterlost(self):
        self.askrepeat = True
        self.winlosticon = 1

    def aftercon(self):
        self.levelcoat()
        self.allanswers = []
        self.allresponse = []
        self.activerow = 0
        self.activecolumn = 0
        self.rowResponse = []
        self.rowblack = 0
        self.rowwhite = 0

    def pressRIGHT(self):
        self.activecolumn += 1
        if self.activecolumn == self.nucolor:
            self.activecolumn = 0

    def pressLEFT(self):
        self.activecolumn -= 1
        if self.activecolumn == -1:
            self.activecolumn = self.nucolor-1

    def pressUP(self):
        self.avlistpointer += 1
        if self.avlistpointer == len(self.avcolor):
            self.avlistpointer = 0

    def pressDOWN(self):
        self.avlistpointer -= 1
        if self.avlistpointer < 0:
            self.avlistpointer = len(self.avcolor)-1

    def pressA(self):
        if self.selectedcolor[self.activecolumn] == 0:
            self.selectedcolor[self.activecolumn] = mmgame.avcolor[self.avlistpointer]
            del mmgame.avcolor[self.avlistpointer]
            self.avlistpointer -= 1
        else:
            mmgame.avcolor.append(self.selectedcolor[self.activecolumn])
            self.selectedcolor[self.activecolumn] = 0
            sorted(mmgame.avcolor)
        self.pressUP()
        self.pressRIGHT()
        #print(self.selectedcolor)

    def gouprow(self):
        self.checkANS()
        self.allanswers.append(self.selectedcolor)
        self.activerow += 1
        self.activecolumn = 0
        self.avcolor = list(mmgame.allcolor[1:self.unknowcolor+1])
        self.selectedcolor = mmgame.zerorow[:self.nucolor]
        if self.rowblack == self.nucolor:
            print("You WON!")
            self.afterwin()
        if self.activerow == self.maxattemp:
            print("You LOST!")
            self.afterlost()

    def checkANS(self):
        self.rowResponse = []
        self.rowblack = 0
        self.rowwhite = 0
        for i in range (0, self.nucolor):
            if self.selectedcolor[i] == self.finalanswer[i]:
                self.rowblack += 1
        for i in self.selectedcolor:
            if i in self.finalanswer:
                self.rowwhite += 1
        self.rowwhite = self.rowwhite-self.rowblack
        for b in range (0, self.rowblack):
            self.rowResponse.append(1)
        for w in range (0, self.rowwhite):
            self.rowResponse.append(0)
        self.allresponse.append(self.rowResponse)
        self.foundcolors = self.rowblack+self.rowwhite
        self.allfoundcolors.append(self.foundcolors)
        print(self.nucolor,self.rowblack,self.rowwhite,self.foundcolors)
        print(self.allfoundcolors)

class main_menu():
    run = True
    backimage_list = []
    pointericon_list = []
    unlockicon_list = []
    poxy_all = (
               ((65,77),(65,107),(65,137),(65,167),(65,197)),
               ((210,210),(15,27),(75,27),(135,27),(195,27),(255,27),\
                (15,87),(75,87),(135,87),(195,87),(255,87),\
                (15,147),(75,147),(135,147),(195,147),(255,147)),
               ((210,210),),
               ((210,210),),
               ((210,210),)
               )
    ulxy_all = (
                (17,30),(77,30),(137,30),(197,30),(257,30),\
                (17,90),(77,90),(137,90),(197,90),(257,90),\
                (17,150),(77,150),(137,150),(197,150),(257,150)
               )

    #bestlevel = blctrl.bl
    lockpo_all = ((52,65),(112,65),(172,65),(232,65),(292,65),\
                  (52,125),(112,125),(172,125),(232,125),(292,125),\
                  (52,185),(112,185),(172,185),(232,185),(292,185))
    def __init__(self):
        self.maxpolo_list = [5,2,1,1,1]
        self.maxpolo_list[1] = blctrl.bl+1
        print(self.maxpolo_list)
        self.bestlevel = blctrl.bl
        self.run = main_menu.run
        self.pagenumber = 0
        self.cpolo = 0
        self.maxpolo = self.maxpolo_list[self.pagenumber]
        self.mpolo = self.maxpolo_list[self.pagenumber]
        self.poxy = main_menu.poxy_all[self.pagenumber][self.cpolo]
        self.backimage = main_menu.backimage_list[self.pagenumber]
        self.pointericon = main_menu.pointericon_list[1]
        self.lockicon = allsign.subsurface((80,205,26,26))
        self.lockpoAll = main_menu.lockpo_all[self.bestlevel:]
        self.unloicon = main_menu.unlockicon_list[:self.bestlevel]
        self.ulxy = main_menu.ulxy_all[:self.bestlevel]

    def update(self):
        pass

    def pressUPpo(self):
        if self.pagenumber == 0:
            self.cpolo -= 1
            if self.cpolo < 0:
               self.cpolo = 4
            self.poxy = main_menu.poxy_all[self.pagenumber][self.cpolo]

    def pressDOWNpo(self):
        if self.pagenumber == 0:
           self.cpolo += 1
           if self.cpolo >= 5:
              self.cpolo = 0
           self.poxy = main_menu.poxy_all[self.pagenumber][self.cpolo]

    def pressRIGHT(self):
        if self.pagenumber == 1:
           self.cpolo += 1
           if self.cpolo >= self.bestlevel+1:
              self.cpolo = 0
           if self.cpolo == 0:
               self.pointericon = main_menu.pointericon_list[1]
           if self.cpolo != 0:
               self.pointericon = main_menu.pointericon_list[0]
           self.poxy = main_menu.poxy_all[self.pagenumber][self.cpolo]

    def pressLEFT(self):
        if self.pagenumber == 1:
           self.cpolo -= 1
           if self.cpolo <= 0:
              self.cpolo = self.bestlevel
           if self.cpolo == 0:
               self.pointericon = main_menu.pointericon_list[1]
           if self.cpolo != 0:
               self.pointericon = main_menu.pointericon_list[0]
           self.poxy = main_menu.poxy_all[self.pagenumber][self.cpolo]

    def pressA(self):
        if self.pagenumber == 0:
           self.pagenumber = self.cpolo+1
           self.cpolo = 0
           if self.pagenumber == 1:
               self.cpolo = 1
               self.pointericon = main_menu.pointericon_list[0]
        elif self.pagenumber == 1:
           if self.cpolo == 0:
               self.pagenumber = 0
               self.cpolo = 0
               self.pointericon = main_menu.pointericon_list[1]
           elif self.cpolo != 0:
               mmgame.run = True
               self.run = False
               mmgame.runlevel = self.cpolo
               mmgame.levelcoat()
        elif 2 <= self.pagenumber <= 4:
           self.pagenumber = 0
           self.cpolo = 0

        self.poxy = main_menu.poxy_all[self.pagenumber][self.cpolo]
        self.backimage = main_menu.backimage_list[self.pagenumber]

dir_data = "data"

allsign = pygame.image.load(os.path.join(dir_data, "allsign.png"))
askconfirm = pygame.image.load(os.path.join(dir_data, "askconfirm.png"))
allsign.convert_alpha()
main_menu.backimage_list.append(pygame.image.load(os.path.join(dir_data,"backimage_0.png")).convert())
main_menu.backimage_list.append(pygame.image.load(os.path.join(dir_data,"backimage_1.png")).convert())
main_menu.backimage_list.append(pygame.image.load(os.path.join(dir_data,"backimage_2.png")).convert())
main_menu.backimage_list.append(pygame.image.load(os.path.join(dir_data,"backimage_3.png")).convert())
main_menu.backimage_list.append(pygame.image.load(os.path.join(dir_data,"backimage_4.png")).convert())

main_menu.pointericon_list.append(allsign.subsurface((15,180,51,51)))
main_menu.pointericon_list.append(allsign.subsurface((80,180,16,21)))

main_menu.unlockicon_list.append(allsign.subsurface((15,15,45,45)))
main_menu.unlockicon_list.append(allsign.subsurface((70,15,45,45)))
main_menu.unlockicon_list.append(allsign.subsurface((125,15,45,45)))
main_menu.unlockicon_list.append(allsign.subsurface((180,15,45,45)))
main_menu.unlockicon_list.append(allsign.subsurface((235,15,45,45)))
main_menu.unlockicon_list.append(allsign.subsurface((15,70,45,45)))
main_menu.unlockicon_list.append(allsign.subsurface((70,70,45,45)))
main_menu.unlockicon_list.append(allsign.subsurface((125,70,45,45)))
main_menu.unlockicon_list.append(allsign.subsurface((180,70,45,45)))
main_menu.unlockicon_list.append(allsign.subsurface((235,70,45,45)))
main_menu.unlockicon_list.append(allsign.subsurface((15,125,45,45)))
main_menu.unlockicon_list.append(allsign.subsurface((70,125,45,45)))
main_menu.unlockicon_list.append(allsign.subsurface((125,125,45,45)))
main_menu.unlockicon_list.append(allsign.subsurface((180,125,45,45)))
main_menu.unlockicon_list.append(allsign.subsurface((235,125,45,45)))

#mmgame
mmgame.colorcircle_list.append(allsign.subsurface((110,180,20,20)))
mmgame.colorcircle_list.append(allsign.subsurface((135,180,20,20)))
mmgame.colorcircle_list.append(allsign.subsurface((160,180,20,20)))
mmgame.colorcircle_list.append(allsign.subsurface((185,180,20,20)))
mmgame.colorcircle_list.append(allsign.subsurface((210,180,20,20)))
mmgame.colorcircle_list.append(allsign.subsurface((235,180,20,20)))
mmgame.colorcircle_list.append(allsign.subsurface((260,180,20,20)))

mmgame.wbcircle_list.append(allsign.subsurface((110,210,10,10)))
mmgame.wbcircle_list.append(allsign.subsurface((130,210,10,10)))

mmgame.endicons_list.append(askconfirm.subsurface((20,20,220,100)))
mmgame.endicons_list.append(askconfirm.subsurface((20,130,220,100)))

def reset_menu():
    blctrl.readbl()
    mmgame.unnexlevel = False
    main_menu.bestlevel = blctrl.bl
    main_menu.pagenumber = 0
    main_menu.cpolo = 0

    main_menu.maxpolo_list[1] = blctrl.bl+1
    print(main_menu.maxpolo_list)
    main_menu.maxpolo = main_menu.maxpolo_list[main_menu.pagenumber]
    main_menu.mpolo = main_menu.maxpolo_list[main_menu.pagenumber]
    main_menu.poxy = main_menu.poxy_all[main_menu.pagenumber][main_menu.cpolo]
    main_menu.lockpoAll = main_menu.lockpo_all[main_menu.bestlevel:]
    main_menu.unloicon = main_menu.unlockicon_list[:main_menu.bestlevel]
    main_menu.ulxy = main_menu.ulxy_all[:main_menu.bestlevel]



    main_menu.poxy = main_menu.poxy_all[main_menu.pagenumber][main_menu.cpolo]
    main_menu.backimage = main_menu.backimage_list[main_menu.pagenumber]
    main_menu.pointericon = main_menu.pointericon_list[1]

main_menu = main_menu()
mmgame = mmgame()
mainloop = True
playtime = 0.0
interval = 0 # how long one single images should be displayed in seconds

while mainloop:
    milliseconds = clock.tick(FPS) # do not go faster than this frame rate
    seconds = milliseconds / 1000.0
    playtime += seconds
    #cycletime += seconds
    # ----- event handler -----
    if main_menu.run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                mainloop = False # pygame window closed by user
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE and main_menu.pagenumber == 0:
                    mainloop = False # user pressed ESC
                if event.key == pygame.K_ESCAPE and main_menu.pagenumber != 0:
                    reset_menu()
                if event.key == pygame.K_UP:
                    main_menu.pressUPpo()
                if event.key == pygame.K_DOWN:
                    main_menu.pressDOWNpo()
                if event.key == pygame.K_RIGHT:
                    main_menu.pressRIGHT()
                if event.key == pygame.K_LEFT:
                    main_menu.pressLEFT()
                if event.key == pygame.K_j:
                    if main_menu.pagenumber == 0 and main_menu.cpolo == 4:
                        mainloop = False # user pressed ESC
                    else :
                       main_menu.pressA()

        #print(mmgame.runlevel)
        screen.blit(main_menu.backimage, (0,0))
        #print(int(playtime)%2)
        interval += 0.1
        if (int(interval)%2) == 0:
           screen.blit(main_menu.pointericon, main_menu.poxy)
        if interval == 100 :
            interval = 0

        # lock & unlock icons
        if main_menu.pagenumber == 1:
            for i in main_menu.lockpoAll:
                screen.blit(main_menu.lockicon, i)
            for i in range(0, main_menu.bestlevel):
                screen.blit(main_menu.unloicon[i], main_menu.ulxy[i])

    if mmgame.run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                mainloop = False # pygame window closed by user
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    mmgame.askrepeat = False
                    mmgame.run = False
                    if mmgame.unnexlevel and mmgame.runlevel == blctrl.bl:
                        if blctrl.bl < 12:
                           blctrl.writebl(blctrl.bl+1)
                    #blctrl.writebl(1)
                    main_menu.run = True
                    reset_menu()
                if event.key == pygame.K_RIGHT and not mmgame.askrepeat:
                    mmgame.pressRIGHT()
                    print(mmgame.activerow, mmgame.activecolumn)
                if event.key == pygame.K_LEFT and not mmgame.askrepeat:
                    mmgame.pressLEFT()
                    print(mmgame.activerow, mmgame.activecolumn)
                if event.key == pygame.K_UP and not mmgame.askrepeat:
                    mmgame.pressUP()
                    #print(mmgame.avlistpointer)
                    #print(mmgame.avcolor[mmgame.avlistpointer])
                if event.key == pygame.K_DOWN and not mmgame.askrepeat:
                    mmgame.pressDOWN()
                    #print(mmgame.avlistpointer)
                if event.key == pygame.K_j:
                    if mmgame.askrepeat:
                        mmgame.askrepeat = False
                        mmgame.aftercon()
                    else :
                        mmgame.pressA()
        screen.blit(background, (0,0))

        for x in range(0, mmgame.nucolor):
            #for y in range(0, 10):
            for y in range(0, mmgame.maxattemp):
                screen.blit(mmgame.colorcircle_list[0], (20+(x*25), (219-(y*24))))

        for i in mmgame.avcolor:
            screen.blit(mmgame.colorcircle_list[i], (290, (220-(i*24))))

        for i in range(0, mmgame.maxattemp-1):
            screen.blit(mmgame.hlineicon, (20,217-(i*24)))

        if sum(mmgame.selectedcolor) > 0:
            y = 0
            for x in range (0, mmgame.nucolor):
                for i in mmgame.selectedcolor:
                    if i != 0:
                        screen.blit(mmgame.colorcircle_list[i], ((20+(y*25), (219-mmgame.activerow*24))))
                    y += 1
                    if y == mmgame.nucolor:
                       y = 0

        if len(mmgame.allanswers) > 0:
            y = 0
            for x in range (0, len(mmgame.allanswers)):
                for j in mmgame.allanswers[x]:
                    screen.blit(mmgame.colorcircle_list[j], ((20+(y*25), (220-(x*24)))))
                    y += 1
                    if y == mmgame.nucolor:
                        y = 0

        if len(mmgame.allresponse) > 0:
            for i in range (0, len(mmgame.allresponse)):
                #for n in range (0, mmgame.nucolor):
                for n in range (0, mmgame.allfoundcolors[i]):
                    x = 230+(n*10)
                    y = 219-(i*24)
                    if n > 2:
                        y = 229-(i*24)
                        x = 230+((n-3)*10)
                    wb = mmgame.allresponse[i][n]
                    screen.blit(mmgame.wbcircle_list[wb], (x,y))

        if mmgame.askrepeat:
            screen.blit(mmgame.endicons_list[mmgame.winlosticon], (50,70))

        interval += 0.1
        if (int(interval)%2) == 0:
           if 0 in mmgame.selectedcolor:
               screen.blit(mmgame.covericon, ((20+(mmgame.activecolumn*25),(219-mmgame.activerow*24))))
           if len(mmgame.avcolor) != 0:
               screen.blit(mmgame.covericon, (290, (220-mmgame.avcolor[mmgame.avlistpointer]*24)))
        if interval == 100 :
            interval = 0
        #screen.blit(mmgame.vlineicon, (225,5))
        pygame.draw.line(screen, (0,0,0), (225,235), (225, (((10-mmgame.maxattemp)*25))+5), 1)
        if not 0 in mmgame.selectedcolor:
            #print("gouprow")
            mmgame.gouprow()
    pygame.display.flip()      # flip the screen like in a flipbook
